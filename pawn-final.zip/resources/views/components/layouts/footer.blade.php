                <!-- Footer Start -->
                <footer class="footer">
                    <div class="container-fluid">
                        <div class="row">
                            <div class="col-md-12 text-left">
                                2023 - 2024 &copy; ພັດທະນາໂດຍ: <a href="">FriendDev</a>
                            </div>
                        </div>
                    </div>
                </footer>
                <!-- end Footer -->